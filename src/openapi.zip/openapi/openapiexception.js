export default class OpenApiException {
    constructor(message){
        this.data = message;
    }
}

