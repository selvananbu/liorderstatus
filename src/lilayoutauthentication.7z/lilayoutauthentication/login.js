import React, { Component } from 'react';
import {  View ,TouchableOpacity , AsyncStorage,TextInput,Picker,StyleSheet,Image,Modal,TouchableHighlight,Alert } from 'react-native'
import { Router, Scene, Actions, ActionConst, Drawer } from 'react-native-router-flux';
import { width, height, totalSize } from 'react-native-dimension';
// import RaisedButton from 'material-ui/RaisedButton';
// import createHistory from 'history/createBrowserHistory';
// import TextField from 'material-ui/TextField';

// import { Header } from '../lilayoutcomponents/lilayoutheader';
import * as commonFunction from '../lib/responseFunction';

// import MenuItem from '@material-ui/core/MenuItem';
// import Select from '@material-ui/core/Select';

import { sha3_512 } from 'js-sha3';
// import {btoa} from 'btoa';
import {decode as atob, encode as btoa} from 'base-64'
import {Buffer} from 'buffer'

import OpenApiClient_auth from '../openapi/openapiclient_auth';
import {getSiteName} from './authutil';
import { CheckBox,Text,Body } from 'react-native-elements';


export default class Login extends Component {

    constructor(props){
        super(props);
        this.state = {
                        username: 'test',
                        password: 'test',
                        selectedSite: AsyncStorage.getItem("config.selectedSiteID") === null ? 0 : parseInt(AsyncStorage.getItem("config.selectedSiteID")),
                        sites: [],
                        keepsignedin:false,
                        isLoggedIn:false,
                        isBaseURLAvailable: false,
                       baseurl: ''
                    }
    }
  
    componentWillMount(){        
          if (this.props.isBaseURLAvailable === false) {
              this.setState({
                  isBaseURLAvailable: false
              });
          } else
              this.loadSites();
    }

    loadSites() {
        OpenApiClient_auth.getClient("dummy").GET_sites(this.callbackLoadSites.bind(this));
    }

    callbackLoadSites(responseData) {

        if (responseData.state.response !== undefined) {
            if (responseData.state.response.status === 200) {
                var result = commonFunction.convertToUint(responseData.state.response.data)
                // console.log(result.sites, 'resul');
                this.setState({sites: result.sites})
            }
            else {
                console.log("Error in load sites");
            }
        }
        else {
            console.log("RESPONSE : " + responseData.state.response);
        }
    }

    generateSitesList(siteList) {
            console.log("Came ehereeeeeeeeeeeeee",siteList);
            
        return (
                <Picker 
                selectedValue={this.state.selectedSite}
                onValueChange={(site,index) => this.handleComboChange(site,index)}
                >
                {
                    siteList.map((siteDetails, siteIndex) => (
                            <Picker.Item key={siteIndex} label = {siteDetails.name} value = {siteDetails.name}/>
                    ))}
                 
                    {/* {
                        siteList.map((siteDetails, siteIndex) => {
                            <Picker.Item value={siteDetails.type} key={siteIndex}  label = {siteDetails.name}/>
                            console.log('====================================');
                            console.log(siteDetails);
                            console.log('====================================');
                        })
                    } */}
                </Picker>
            )
    }

    handleComboChange(site,index) {
        // console.log("COMBO VALUE", event.target.value)
        this.setState({selectedSite: site });     
        
        commonFunction.setStorageItem("config.selectedSiteID", site);
    }

    doLogin = async () => {
        let username = this.state.username;
        let password = this.state.password;
        let siteName = this.state.selectedSite; // initial set

        // console.log(username + "======" + siteName);

        commonFunction.setStorageItem("config.username", username);
        commonFunction.setStorageItem("config.sitename", siteName);

        var arrayBuffer = sha3_512.arrayBuffer(password);
       
        var base64StringPassword = btoa(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer))) 
        // var base64StringPassword = Buffer.from(arrayBuffer).toString('base64');

        // console.log(username + "<<<<<<<>>>>>>>" + btoa(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer))));

        OpenApiClient_auth.getClient(siteName).POST_tokens(this.callbackDoLogin.bind(this), username, base64StringPassword, null, null);
                // let siteName = await commonFunction.getStorageItem("config.sitename");
          
        // OpenApiClient_auth.getClient(siteName).POST_tokens(this.callbackDoLogin.bind(this), null, null, username, base64StringPassword);
    }

    doLogout = async () =>{
                  let siteName = await getSiteName();
                  let refreshToken = await commonFunction.getStorageItem("config.refreshToken." + siteName);
                 console.log("Logging Outttttttttttt");
                  OpenApiClient_auth.getClient(siteName).DELETE_tokens(this.callbackDoLogout.bind(this), refreshToken);
    }
    callbackDoLogout = async (responseData) => {
        console.log("Cameeeeeeeeeeeeeeeee",responseData);
        
        if (responseData.state.response !== undefined) {
            if (responseData.state.response.status === 200) {
                    console.log('Logout success=================');
                    let siteName = await getSiteName();
                    await commonFunction.removeStorageItem("core.refreshToken." + siteName)
                    commonFunction.removeStorageItem("config.accessToken." + siteName, result.accessToken);
                    commonFunction.removeStorageItem("config.loggedin", "true");
                    Actions.HomeScreen();
            }
        }
    }

    callbackDoLogin = async  (responseData) => {
        if (responseData.state.response !== undefined) {
            if (responseData.state.response.status === 200) {
                var result = commonFunction.convertToUint(responseData.state.response.data)
                
                let siteName = await getSiteName();
                console.log(siteName, 'Login success=================');

                
                commonFunction.setStorageItem("config.refreshToken." + siteName, result.refreshToken);
                commonFunction.setStorageItem("config.accessToken." + siteName, result.accessToken);
                commonFunction.setStorageItem("config.loggedin", "true");

                Actions.HomeScreen();
                // history.push("/webapp1/orderStatus");
                // history.go();
            }
            else {
                console.log("Error in login");
            }
        }
        else {
            console.log("RESPONSE : " + responseData.state.response);
        }
    }

    verifyAccessToken() {
        let siteName = getSiteName();
        let accessToken = AsyncStorage.getItem("config.accessToken." + siteName);

        return OpenApiClient_auth.getClient(siteName).GET_tokens(this.callbackVerifyAccessToken.bind(this), null, accessToken);
    }

    callbackVerifyAccessToken(responseData) {
        //return new Promise(function (resolve, reject) {
            if (responseData.state.response !== undefined) {
                if (responseData.state.response.status === 200) {
                    var result = commonFunction.convertToJSON(responseData.state.response.data)
                    console.log('recieved result.........');
                }
                else if (responseData.state.response.response.status === 406) {
                    console.log(responseData.state.response.response.statusText + " :: Token expired");
                }
                else {
                    console.log("Error in verification");
                }
            }
            else {
                console.log("RESPONSE : " + responseData.state.response);
            }
        //})
    }


    render() {
        return (
                <View style={{flex:1}}>
                        {this.state.isBaseURLAvailable === false
                        ?
                            <Modal
                            animationType="slide"
                            transparent={true}
                            visible={this.state.modalVisible}
                            onRequestClose={() => {
                            alert('Modal has been closed.');
                            }}>
                            < View style = {
                                    {
                                       marginHorizontal:width(24),marginVertical:height(33),
                                        height: height(30), width: width(50), paddingVertical: height(5),
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        backgroundColor: 'rgba(255,255,255,0.95)',
                                        flexDirection:'column'
                                        }}>
                            <View>
                              <TextInput
                                            style={{width:width(35)}}
                                            placeholder="Enter your Base URL..."
                                            secureTextEntry={true}
                                            value={this.state.baseurl}
                                            onChange={event => this.setState({ baseurl: event.target.value })}
                                            />
                                            <TouchableOpacity
                                            
                                            onPress={event => this.setState({ baseurl: event.target.value,isBaseURLAvailable:true})}>
                                                <Text>OK</Text>
                                            </TouchableOpacity>
                            </View>
                            </View>
                            </Modal>
                        :
                        <View style={{width:width(98),height:height(98)}}>
                                 <TextInput
                                 style={{width:width(100),height:height(8),fontWeight: 'bold',fontFamily: 'Cochin'}} 
                                placeholder="Enter Base URL...."
                                value={this.state.baseurl}
                                secureTextEntry={true}
                                />
                                
                                <View style={{width:width(98),height:height(25),alignItems:'center'}}>
                                       <Image  style={styles.ImageIconStyle2}  source={{uri:'src_image_user'}}/>
                                </View>

                                <TextInput
                                style={{width:width(100),height:height(8), fontSize: 17,fontWeight: 'bold',fontFamily: 'Cochin'}} 
                                placeholder="Enter your Username"
                                onChange={event => this.setState({ username: event.target.value })}
                                value={this.state.username}
                                />

                                <TextInput
                                 style={{width:width(100),height:height(8), fontSize: 17,fontWeight: 'bold',fontFamily: 'Cochin'}} 
                                placeholder="Enter your Password"
                                secureTextEntry={true}
                                onChange={event => this.setState({ password: event.target.value })}
                                value={this.state.password}
                                />
                                <Text style={styles.loadText}>Site:</Text>   
                                <View style={{width:width(98),height:height(7),margin:3,borderWidth:1, borderColor:'#881b4c',borderRadius:15}}>
                                        {this.state.sites !== null
                                        ?
                                            this.generateSitesList(this.state.sites)
                                        :<View/>
                                        }
                                </View>
                                <View style={{alignItems:"center",marginTop:height(5)}}>
                                    {this.state.isLoggedIn === true
                                    ?
                                    <TouchableOpacity  style = {styles.buttonContainer} onPress={() => this.doLogout()}>
                                          <Text style={styles.textContainer}>Logout</Text>
                                    </TouchableOpacity>
                                    :
                                    <TouchableOpacity style = {styles.buttonContainer} onPress={() => this.doLogin()}>
                                          <Text style={styles.textContainer}>Login</Text>
                                    </TouchableOpacity>
                                    }
                                    <View style={{flexDirection:'row'}}>
                                    <CheckBox style={{backgroundColor:'#f2eff4',color:"#f2eff4"}} checked={this.state.keepsignedin}
                                     onPress={() => this.setState({keepsignedin:!this.state.keepsignedin})} />
                                    <Text style={{alignItems:'center',justifyContent:'center',height:height(8)}}>Keep Me Signed In.</Text>
                                    </View>
                                </View>
                        </View> 
                        }
                </View>
        )
    }
}
const styles = StyleSheet.create({
                container: {
                flex: 1,
                },
                loadText: {
                fontSize: 15,
                fontWeight: 'bold',
                fontFamily: 'Cochin',
                alignItems: 'center',
                color: '#881b4c'
                },
                 loadText: {
                fontSize: 15,
                justifyContent:'center',
                fontFamily: 'Cochin',
                alignItems: 'center',
                color: '#881b4c'
                },
                buttonContainer:{
                backgroundColor: '#a0185c',
                paddingVertical:15,
                borderRadius: 25,
                width:300,
                height:height(8),
                margin:5,
                justifyContent: 'flex-end',
                alignItems: 'center',
                },
                buttonURLContainer:{
                backgroundColor: '#a0185c',
                paddingVertical:15,
                borderRadius: 25,
                width:width(15),
                height:height(5),
                margin:5,
                justifyContent: 'flex-end',
                alignItems: 'center',
                },
                textContainer:{
                fontSize: 24,
                color: '#FFF',
                textAlign: 'center',
                fontWeight: 'bold',
                },
                 ImageIconStyle2: {
                height: height(16),
                width: width(98),
                marginTop: height(7),
                resizeMode : 'contain',
                justifyContent: 'center',
                alignItems: 'center'
            },
        });